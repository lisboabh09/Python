
def media(a, b, c, d):
    return (a + b + c + d)/4


def bem_vindo():
    print('Bem vindo')