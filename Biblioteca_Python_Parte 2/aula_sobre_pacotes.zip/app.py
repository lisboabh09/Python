from pacote_media_escolar.media_escolar import media, bem_vindo

media = media(8, 9, 7, 9)
bem_vindo()
print(media)