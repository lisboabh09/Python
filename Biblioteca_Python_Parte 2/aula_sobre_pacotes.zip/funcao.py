
def soma(x, y):
    resultado = x + y
    print(resultado)


# soma(8, 9)


def subratacao(a, b):
    return a - b

resultado = subratacao(19, 9)

print(resultado)